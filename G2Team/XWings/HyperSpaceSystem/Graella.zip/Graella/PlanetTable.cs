﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Graella
{
    public partial class PlanetTable: UserControl
    {
        Panel p1, p2;
        #region propfulls 

        private int num1, let1, num2, let2;
        string planeta;
        public int Num1
        {
            get { return num1; }
            set { num1 = value; }
        }

        public int Let1
        {
            get { return let1; }
            set { let1 = value; PaintChart(num1, let1, Color.BlueViolet); }
        }

        public int Num2
        {
            get { return num2; }
            set { num2 = value; }
        }
        public int Let2
        {
            get { return let2; }
            set { let2 = value; }
        }
        public string Planeta
        {
            get { return planeta; }
            set { planeta = value; }
        }

        #endregion
        public PlanetTable()
        {
            InitializeComponent();
        }
        private void PaintChart(int let, int num, Color c)
        {
            foreach (Control ct in panel18.Controls)
            {
                if (ct.Tag != null && ct.Tag.ToString() == "P")
                {
                    panel18.Controls.Remove(ct);
                }
            }
            Panel p1 = new Panel();
            p1.Width = 10;
            p1.Tag = "P";
            p1.Height = 10;
            p1.BackColor = c;
            p1.Location = new Point((int)Math.Round(((let + 1) * 67.3) * 0.734) + (let * 68), (int)Math.Round((num * 37.5 *0.63) + ((num - 1)  * 50)));
            panel18.Controls.Add(p1);
        }
        private void UserControl1_Load(object sender, EventArgs e)
        {

        }
    }
}
